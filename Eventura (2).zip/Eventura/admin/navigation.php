<header>
    <img src="../assets/images/e2.png" alt="" style="width: 100px;">
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="add_admin.php">Add Admin</a>
        <a href="create_event.php">Create Event</a>
        <a href="manage_events.php">Manage Events</a>
        <a href="manage_users.php">Manage Admins</a>
        <a href="admin_logout.php">Logout</a>
    </nav>
</header>
