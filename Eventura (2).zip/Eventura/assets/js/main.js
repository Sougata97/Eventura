// main.js
document.addEventListener("DOMContentLoaded", () => {
  console.log("JavaScript loaded and ready!");
});
